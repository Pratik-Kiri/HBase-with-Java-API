//import org.apache.hadoop.conf.Configuration;
//import org.apache.hadoop.hbase.HBaseConfiguration;
//import org.apache.hadoop.hbase.HColumnDescriptor;
//import org.apache.hadoop.hbase.HTableDescriptor;
//import org.apache.hadoop.hbase.TableName;
//import org.apache.hadoop.hbase.client.Admin;
//import org.apache.hadoop.hbase.client.Connection;
//import org.apache.hadoop.hbase.client.ConnectionFactory;
//
//public class InsertData {
//
//    public static void main(String[] args) {
//        Configuration conf = HBaseConfiguration.create();
//        try {           
//            Connection conn = ConnectionFactory.createConnection(conf);
//            Admin hAdmin = conn.getAdmin();
//
//            HTableDescriptor hTableDesc = new HTableDescriptor(
//                    TableName.valueOf("Customer"));
//            hTableDesc.addFamily(new HColumnDescriptor("name"));
//            hTableDesc.addFamily(new HColumnDescriptor("contactinfo"));
//            hTableDesc.addFamily(new HColumnDescriptor("address"));
//
//            hAdmin.createTable(hTableDesc);
//
//            System.out.println("Table created Successfully...");
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
//}



import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.HColumnDescriptor;
import org.apache.hadoop.hbase.HTableDescriptor;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.Admin;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.ConnectionFactory;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.util.Bytes;

public class InsertData{

   public static void main(String[] args) throws IOException {

      // instantiate Configuration class
      Configuration config = HBaseConfiguration.create();
      
      Connection conn = ConnectionFactory.createConnection(config);
    Admin hAdmin = conn.getAdmin();

    	HTableDescriptor hTableDesc = new HTableDescriptor(
            TableName.valueOf("employee"));
    	
    	 hTableDesc.addFamily(new HColumnDescriptor("personal"));
    	
    	hAdmin.createTable(hTableDesc);

      // instantiate HTable class
      HTable hTable = new HTable(config, "employee");

      // instantiate Put class
      Put p = new Put(Bytes.toBytes("row2001"));

      // add values using add() method
      p.add(Bytes.toBytes("personal"),
		Bytes.toBytes("name"),Bytes.toBytes("Vivek"));
      p.add(Bytes.toBytes("personal"),
		Bytes.toBytes("age"),Bytes.toBytes("17"));
      p.add(Bytes.toBytes("contactinfo"),Bytes.toBytes("city"),
		Bytes.toBytes("Bengaluru"));
      p.add(Bytes.toBytes("contactinfo"),Bytes.toBytes("country"),
		Bytes.toBytes("India"));
      p.add(Bytes.toBytes("contactinfo"),Bytes.toBytes("email"),
		Bytes.toBytes("vivek@abcd.com"));
      
      // save the put Instance to the HTable.
      hTable.put(p);
      System.out.println("data inserted successfully");
      
      hAdmin.close();
   }
}