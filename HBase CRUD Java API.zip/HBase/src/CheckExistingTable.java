import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.client.HBaseAdmin;

public class CheckExistingTable {
public static void main(String args[])throws IOException{
Configuration c = HBaseConfiguration.create();      // Instantiate configuration class
HBaseAdmin ad = new HBaseAdmin(c);      // Instantiate HBaseAdmin class
Boolean boolean1 = ad.tableExists("student");       // Cheking the existance of the table
System.out.println( boolean1);
}
}
